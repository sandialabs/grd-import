function varargout = GRDImport(varargin)
% GRDIMPORT M-file for GRDImport.fig
%      GRDIMPORT opens a GUI that steps the user through the import
%      process.
%
%      From the GUI, one can parse a GRD file into a Matlab matrix and save
%      the file.  The GUI does not have a batch mode.  Files must be
%      imported one at a time.
%       
%      ***Works only for GRD files created in SurfaceLab 6.1 or later
%         Use ExportITMtoGRD.recipe in the measurement explorer.
%           --  DO NOT select "Split into 4 files..." 
%           --  Select "Suppress creation of scans..."  (this program is
%               not compatible with the "split" GRD files at this time)
%           --  Sele5ct "Create additonal file that contains all header..."
%
%      ***Must have the following 3 files for each dataset to work: 
%       (filename is the root filename of the original filename.itm dataset)
%              filename.itm.grd
%              filename.itm.bmp
%              filename.properties.txt
%         --follow procedure above to create the 3 files
%
%      ***Binning centers on the mass bin window.  Offset shifts the bin.
%          not the spectra.  So, with mas resolutuion of 1, normally, the
%          bin would be from -0.5 to +0.5 of the nominal mass.  A shift of
%          0.25 would place the bin at -0.25 and 0.75 from the nominal mass.
%
%      User starts by selecting a file to load.  The filename.properties.txt
%      and filename.itm.bmp files are loaded so that acquisition conditions
%      are known.  Additionally the total ion image is displayed to visualize
%      spatial binning.  User selects row, column and depth binning as well 
%      as spectral start and end values along with spectral binning.  
%      GRD file are binned into a matrix along with variables denoting data
%      sizes in all dimensions.
%
%      When the user selects 'Import and Save', the *.itm.grd file is
%      parsed into the matlab data structures, then saved as filename.mat
% 
%                               NOTICE:
% For five (5) years from 10/29/2010, the United States Government is granted 
% for itself and others acting on its behalf a paid-up, nonexclusive, 
% irrevocable worldwide license in this data to reproduce, prepare derivative 
% works, and perform publicly and display publicly, by or on behalf of the 
% Government. There is provision for the possible extension of the term of 
% this license. Subsequent to that period or any extension granted, the 
% United States Government is granted for itself and others acting on its 
% behalf a paid-up, nonexclusive, irrevocable worldwide license in this data 
% to reproduce, prepare derivative works, distribute copies to the public, 
% perform publicly and display publicly, and to permit others to do so. The 
% specific term of the license can be identified by inquiry made to Sandia 
% Corportation or DOE.
 
% NEITHER THE UNITED STATES GOVERNMENT, NOR THE UNITED STATES DEPARTMENT OF 
% ENERGY, NOR SANDIA CORPORATION, NOR ANY OF THEIR EMPLOYEES, MAKES ANY 
% WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LEGAL RESPONSIBILITY FOR THE 
% ACCURACY, COMPLETENESS, OR USEFULNESS OF ANY INFORMATION, APPARATUS, 
% PRODUCT, OR PROCESS DISCLOSED, OR REPRESENTS THAT ITS USE WOULD NOT 
% INFRINGE PRIVATELY OWNED RIGHTS.
 
% Any licensee of this software has the obligation and responsibility to 
% abide by the applicable export control laws, regulations, and general 
% prohibitions relating to the export of technical data. Failure to obtain 
% an export control license or other authority from the Government may 
% result in criminal liability under U.S. laws.


% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GRDImport_OpeningFcn, ...
                   'gui_OutputFcn',  @GRDImport_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --------------------------------------------------------------------
function About_Callback(hObject, eventdata, handles)
% hObject    handle to About (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Version 1.0  5-17-2010 By JAO, Program created.  Initial version.
% Version 1.0a 8-17-2010 by JAO, bug fixed:  spectral offset not working correctly
%                                and formula for binning spectra incorrect
% Version 1.0b 11-1-2010 by JAO, added error checking for max array size.

msgbox ('Version 1.0b  11-1-2010 JAO SNL.   Copyright 2010 Sandia Corporation. Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive license for use of this work by or on behalf of the U.S. Government. Export of this program may require a license from the United States Government.    NOTICE:  For five (5) years from 10/29/2010, the United States Government is granted for itself and others acting on its behalf a paid-up, nonexclusive, irrevocable worldwide license in this data to reproduce, prepare derivative works, and perform publicly and display publicly, by or on behalf of the Government. There is provision for the possible extension of the term of this license. Subsequent to that period or any extension granted, the United States Government is granted for itself and others acting on its behalf a paid-up, nonexclusive, irrevocable worldwide license in this data to reproduce, prepare derivative works, distribute copies to the public, perform publicly and siplay publicly, and to permit others to do so. The specific term of the license can be identified by inquiry made to Sandia Corportation or DOE.  NEITHER THE UNITED STATES GOVERNMENT, NOR THE UNITED STATES DEPARTMENT OF ENERGY, NOR SANDIA CORPORATION, NOR ANY OF THEIR EMPLOYEES, MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR ASSUMES ANY LEGAL RESPONSIBILITY FOR THE ACCURACY, COMPLETENESS, OR USEFULNESS OF ANY INFORMATION, APPARATUS, PRODUCT, OR PROCESS DISCLOSED, OR REPRESENTS THAT ITS USE WOULD NOT INFRINGE PRIVATELY OWNED RIGHTS.  Any licensee of this software has the obligation and responsibility to abide by the applicable export control laws, regulations, and general prohibitions relating to the export of technical data. Failure to obtain an export control license or other authority from the Government may result in criminal liability under U.S. laws.','GRDImport About'); 


% --- Executes just before GRDImport is made visible.
function GRDImport_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GRDImport (see VARARGIN)

% Choose default command line output for GRDImport
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Initialize Variables

global filename;
filename='';
global binview;
binview=0;

dummy=zeros(128,128);
set(gcf,'CurrentAxes',handles.axes1);
imagesc(dummy);, axis image off; colormap(gray);

h=msgbox ('Version 1.0a  8-17-2010 JAO SNL.   Copyright 2010 Sandia Corporation. Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive license for use of this work by or on behalf of the U.S. Government. Export of this program may require a license from the United States Government.','GRDImport'); 
uiwait(h);

% UIWAIT makes GRDImport wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GRDImport_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;




function BinnedWidth_Callback(hObject, eventdata, handles)
% hObject    handle to BinnedWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BinnedWidth as text
%        str2double(get(hObject,'String')) returns contents of BinnedWidth as a double
global binview;
binview=1;

CalcBinned (handles);



% --- Executes during object creation, after setting all properties.
function BinnedWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BinnedWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function BinnedHeight_Callback(hObject, eventdata, handles)
% hObject    handle to BinnedHeight (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BinnedHeight as text
%        str2double(get(hObject,'String')) returns contents of BinnedHeight as a double
global binview;
binview=1;

CalcBinned (handles);

% --- Executes during object creation, after setting all properties.
function BinnedHeight_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BinnedHeight (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function BinnedDepth_Callback(hObject, eventdata, handles)
% hObject    handle to BinnedDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BinnedDepth as text
%        str2double(get(hObject,'String')) returns contents of BinnedDepth as a double


CalcBinned (handles);

% --- Executes during object creation, after setting all properties.
function BinnedDepth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BinnedDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MassK0_Callback(hObject, eventdata, handles)
% hObject    handle to MassK0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MassK0 as text
%        str2double(get(hObject,'String')) returns contents of MassK0 as a double


% --- Executes during object creation, after setting all properties.
function MassK0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MassK0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MassSF_Callback(hObject, eventdata, handles)
% hObject    handle to MassSF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MassSF as text
%        str2double(get(hObject,'String')) returns contents of MassSF as a double


% --- Executes during object creation, after setting all properties.
function MassSF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MassSF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MassStart_Callback(hObject, eventdata, handles)
% hObject    handle to MassStart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MassStart as text
%        str2double(get(hObject,'String')) returns contents of MassStart as a double

BinnedSpec(handles)

% --- Executes during object creation, after setting all properties.
function MassStart_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MassStart (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MassEnd_Callback(hObject, eventdata, handles)
% hObject    handle to MassEnd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MassEnd as text
%        str2double(get(hObject,'String')) returns contents of MassEnd as a double

BinnedSpec(handles)


% --- Executes during object creation, after setting all properties.
function MassEnd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MassEnd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MassBin_Callback(hObject, eventdata, handles)
% hObject    handle to MassBin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MassBin as text
%        str2double(get(hObject,'String')) returns contents of MassBin as a double

BinnedSpec(handles)

% --- Executes during object creation, after setting all properties.
function MassBin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MassBin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%set(handles.MassBin, 'String',{'1','0.5','0.25','0.125','0.0625','0.03125'...
%    ,'0.015625','0.0078125','0.00390625','0.001953125'});



% --- Executes during object creation, after setting all properties.
function MassOffset_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MassOffset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function ShotsPixel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ShotsPixel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function TotalShots_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TotalShots (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --------------------------------------------------------------------
function FileOpen_Callback(hObject, eventdata, handles)
% hObject    handle to FileOpen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global filename pathname filterindex filemat;
global Header SICount;
global meanimage;

[filename,pathname,filterindex] = uigetfile('*.grd');

set(handles.Status, 'String','Opening Header File');
cd(pathname);
fileroot=filename(1:size(filename,2)-4);
fileroot1=filename(1:size(fileroot,2)-4);
filebmp=[fileroot '.bmp'];
filemat=[fileroot1 '.mat'];
fileheader=[fileroot(1:size(fileroot,2)-4) '.properties.txt'];

%Import Header information an place in cell array (Created in SL6 exporter)
fid = fopen(fileheader);
Header = textscan(fid, '%s %s %s %s', 'delimiter', '\t');
fclose(fid);

%Import Mean image BMP (created from ITRawExport) and plot
meanimage = imread(filebmp, 'bmp');
set(gcf,'CurrentAxes',handles.axes1);
imagesc(meanimage);, axis image off; colormap(gray);

%Pull data from Header cell array
CalK0= str2num(char(Header{1,3}(find(strcmp(Header{1,1},'Context.MassScale.K0')))));
CalSF = str2num(char(Header{1,3}(find(strcmp(Header{1,1},'Context.MassScale.SF')))));
TotalShots = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Measurement.PIShots')))));
TotalScans = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Measurement.ScanNumber')))));
stageraster = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Registration.Raster.StageRaster')))));
if stageraster==1
   rawnrows = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Registration.Raster.StageRaster.TotalResolution.X')))));
else
   rawnrows = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Registration.Raster.Resolution')))));
end
rawncols=rawnrows;
rawndepths=TotalScans;
ShotsPerPixel = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Registration.Raster.ShotsPerPixel')))));
LowerMass = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Measurement.LowerMass')))));
UpperMass = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Measurement.UpperMass')))));
SICount = str2num(char(Header{1,2}(find(strcmp(Header{1,1},'Measurement.SICount')))));

%setup display with raw data values
set(handles.RawWidth, 'String',num2str(rawncols));
set(handles.BinnedWidth, 'String',num2str(factorize(rawncols)'));
set(handles.BinnedWidth, 'Value',1);
set(handles.RawHeight, 'String',num2str(rawncols));
set(handles.BinnedHeight, 'String',num2str(factorize(rawncols)'));
set(handles.BinnedHeight, 'Value',1);
set(handles.RawDepth, 'String',num2str(rawndepths));
set(handles.EndDepth, 'String',num2str(rawndepths));
set(handles.StartDepth, 'String',num2str(1));
set(handles.BinnedDepth, 'String',num2str(factorize(rawndepths)'));
set(handles.BinnedDepth, 'Value',1);
totpixels=rawncols*rawnrows*rawndepths;
set(handles.TotalPixels, 'String',num2str(totpixels));
set(handles.TotalShots, 'String',num2str(TotalShots));
set(handles.TotalCounts, 'String',num2str(SICount));
set(handles.ShotsPixel, 'String',num2str(ShotsPerPixel));
set(handles.BinnedShotPix, 'String',num2str(ShotsPerPixel));
set(handles.FileTag, 'String',[pathname,filename]);

if handles.MassStart==0 
    handles.MassStart=1; 
end
set(handles.MassStart, 'String',num2str(LowerMass));
set(handles.MassEnd, 'String',num2str(UpperMass));
set(handles.MassK0, 'String',num2str(CalK0));
set(handles.MassSF, 'String',num2str(CalSF));
set(handles.MassBin, 'Value',1);

CalcBinned(handles);
BinnedSpec(handles);
set(handles.Status, 'String','Header File Loaded');

% --------------------------------------------------------------------
function MenuImportSave_Callback(hObject, eventdata, handles)
% hObject    handle to MenuImportSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


global filename pathname filemat Header SICount datasize;

[user sys]=memory;
if datasize > sys.PhysicalMemory.Available
  %error
  errordlg('Array size too large. Change parameters to reduce array size.','Size Error');
else

if filename

set(handles.Status, 'String','Preparing Variables');
drawnow;
% get cal info
CalK0=str2num(get(handles.MassK0, 'String'));
CalSF=str2num(get(handles.MassSF, 'String'));
    
% first setup variables and empty specdata
ys= str2num(get(handles.BinnedHeight, 'String'));
yv= get(handles.BinnedHeight, 'Value');
nrows=ys(yv);
xs= str2num(get(handles.BinnedWidth, 'String'));
xv= get(handles.BinnedWidth, 'Value');
ncols=xs(xv);
zs= str2num(get(handles.BinnedDepth, 'String'));
zv= get(handles.BinnedDepth, 'Value');
ndepths=zs(zv);
totpix=ncols*nrows*ndepths;
as= get(handles.ArrayType, 'String');
av= get(handles.ArrayType, 'Value');
at=as(av);
arraytype=at{1,1};

shotsperpixel=str2num(get(handles.BinnedShotPix, 'String'));
rawncols=str2num(get(handles.RawWidth, 'String'));
rawnrows=str2num(get(handles.RawHeight, 'String'));
rawndepths=str2num(get(handles.RawDepth, 'String'));

lowmass= str2num(get(handles.MassStart, 'String'));
highmass= str2num(get(handles.MassEnd, 'String'));
offset= str2num(get(handles.MassOffset, 'String'));
mbs= get(handles.MassBin, 'String');
mbv= get(handles.MassBin, 'Value');
resolution=str2num(mbs{mbv});
nchannels=1+(highmass-lowmass)/resolution;
xaxis=lowmass:resolution:highmass;
maxint=1;
switch arraytype
    case ('uint16')
        specdata = zeros(nchannels,totpix,'uint16');
        maxint=65535;
    case ('uint32')
        specdata = zeros(nchannels,totpix,'uint32');
        maxint=4294999999;
    case ('double')
        specdata = zeros(nchannels,totpix,'double');
        maxint=inf;
end    

shiftrows=rawnrows/nrows-1;
shiftcols=rawncols/ncols-1;
shiftdepths=rawndepths/ndepths-1;


%   Prepare status display
status=zeros(1,100,3);
status(:,:,:)=0.5;
set (gcf,'CurrentAxes',handles.axes2);
bar1=image(status,'EraseMode','none');
hold on;
set (bar1,'CData',status);
axis image off;
drawnow;

%profile on -history;

fid = fopen([pathname,filename]);
set(handles.Status, 'String','Parsing Raw (GRD) File');
drawnow;
SiReadCount=0;
barnext=fix(SICount/100); %1 percent at a time
ttot=0;
tinc=0;
tic;
arsize=10*1024;
numar=(1+fix(SICount/arsize));
lastarsize=SICount-(arsize*(numar-1));
dummyar=zeros(5,arsize);

for i=1:numar
  %read information for next ion block
  
  if i==numar
      dummyar=fread(fid,[5,lastarsize],'uint32');
      asize=lastarsize;
  else
      dummyar=fread(fid,[5,arsize],'uint32');
      asize=arsize;
  end
  
  for j=1:asize
      SiReadCount=SiReadCount+1;
      fscan = dummyar(1,j); 
      fx = dummyar(3,j);
      fy = dummyar(4,j);
      ftof = dummyar(5,j)+1;

  %convert tof to mass
  mass=((ftof - CalK0)/CalSF)^2;
  massoff=mass+(0.5*resolution)-offset;
  if ((massoff < lowmass) | (massoff > highmass))
      continue
  elseif mass == NaN
      continue
  else
    %put pixel in correct pixel index    
    z1=fix((fscan+1+shiftdepths)*ndepths/rawndepths);
    x1=fix((fx+1+shiftcols)*ncols/rawncols);
    y1=fix((fy+1+shiftrows)*nrows/rawnrows);
    spec = y1 + ((x1-1)*(nrows)) + ((nrows)*(ncols)*(z1-1));
    
    %put pixel in correct spectral channel index
    channel = 1+fix((nchannels-1)*(massoff-lowmass)/(highmass-lowmass));
    
    %store change in specdata
    specdata(channel,spec)=specdata(channel,spec)+1;
    if specdata(channel,spec) == maxint
        msgbox('Voxel has reached its maximum allowed value.  Change binning or choose a larger array type.','Modal');
        return
    end
  end
  end
 %update status display  (only 1 block at a time)
    status(:,1+floor(100*i/numar),:)=[0,1,0];
    set (gcf,'CurrentAxes',handles.axes2);
    hold on;
    bar1=image(status,'EraseMode','none');
    set (bar1,'CData',status);
    axis off;
    
    tinc=tinc+1;
    t=toc;
    ttot=ttot+t;
    tave=ttot/tinc;
    if t<60
        tstr=[num2str(t,'%4.2f') ' s'];
    else
        tstr=[num2str(t/60,'%4.2f') ' m'];
    end
    set(handles.TimePerStep, 'String',tstr);  
    timeleft=tave*(numar-tinc);
    if ttot < 60
        ttstr=[num2str(ttot,'%4.2f') ' s'];
    else
        ttstr=[num2str(ttot/60,'%4.2f') ' m'];
    end
    set(handles.TimeElapsed, 'String',ttstr);
    if timeleft<60
        tleftstr= [num2str(timeleft,'%4.2f') ' s'];
    else
        tleftstr=[num2str(timeleft/60,'%4.2f') ' m'];
    end
    set(handles.TimeLeft, 'String',tleftstr);  drawnow;
    tic; 
end
a=[pathname filemat];   
set(handles.Status, 'String','Saving MAT file');
drawnow;
save(a,'specdata','nrows','ncols','ndepths','resolution','xaxis','nchannels','shotsperpixel','Header','-V6'); 
set(handles.Status, 'String','Saving Complete');
drawnow;
%msgbox('File was saved.');

%profile off;
%profile viewer;

else
    errordlg('No file loaded.');
end
end



function finish = factorize(n)
% computes factors of n for binning and returns a matrix of strings

finish=n;

f=factor(n);
for i=1:size(f,2)
    m=n;
    m=m/f(i);
    while m>1   
        if (m==fix(m))
            finish=[finish m];
        end
        m=m/f(i);
    end    
end

finish=[finish 1];
finish=sort(finish,'descend');

x=1;
while x<size(finish,2)
    if finish(x)==finish(x+1)
        finish=[finish(1:x) finish(x+2:size(finish,2))];
    else
    x=x+1;
    end
end

function CalcBinned(handles)
% Calculates new binned image data and updates screen
global meanimage binnedimage binview;

ys= str2num(get(handles.BinnedHeight, 'String'));
yv= get(handles.BinnedHeight, 'Value');
y=ys(yv);
xs= str2num(get(handles.BinnedWidth, 'String'));
xv= get(handles.BinnedWidth, 'Value');
x=xs(xv);
zs= str2num(get(handles.BinnedDepth, 'String'));
zv= get(handles.BinnedDepth, 'Value');
z=zs(zv);
shots=str2num(get(handles.TotalShots, 'String'));
spp=shots/x/y/z;
set(handles.BinnedShotPix, 'String',num2str(spp));
totbins=x*y*z;
set(handles.TotBinnedPix, 'String',num2str(totbins));

rawncols=str2num(get(handles.RawWidth, 'String'));
rawnrows=str2num(get(handles.RawHeight, 'String'));
rawndepths=str2num(get(handles.RawDepth, 'String'));
bincol=rawncols/x;
binrow=rawnrows/y;
bindepth=rawndepths/z;
set(handles.ColsBin, 'String',num2str(bincol));
set(handles.RowsBin, 'String',num2str(binrow));
set(handles.DepthsBin, 'String',num2str(bindepth));
allbin=bincol*binrow*bindepth;
set(handles.TotBin, 'String',num2str(allbin));

TotalCounts=str2num(get(handles.TotalCounts, 'String'));
cprawp=TotalCounts/(rawncols*rawnrows*rawndepths);
set(handles.AvgCntsPix, 'String',num2str(cprawp));
cpp=TotalCounts/totbins;
set(handles.AvgCntsBinnedPix, 'String',num2str(cpp));

if ((rawncols==x) & (rawnrows==y))
    binnedimage=double(meanimage);
else
    % bin the meanimage
    binnedimage=zeros(y,x,'double');
    for i=1:rawncols
        for j=1:rawnrows
            %move pixel
            xb=1+fix((i-1)*y/rawncols);
            yb=1+fix((j-1)*x/rawnrows);
            binnedimage(xb,yb)=binnedimage(xb,yb)+double(meanimage(i,j));
        end
    end
end
set(handles.ImageSelect,'SelectedObject',handles.BinnedImage); 
binview=1;
CalcSize(handles);
DispImage(handles);

function CalcSize(handles)

global datasize;

ys= str2num(get(handles.BinnedHeight, 'String'));
yv= get(handles.BinnedHeight, 'Value');
y=ys(yv);
xs= str2num(get(handles.BinnedWidth, 'String'));
xv= get(handles.BinnedWidth, 'Value');
x=xs(xv);
zs= str2num(get(handles.BinnedDepth, 'String'));
zv= get(handles.BinnedDepth, 'Value');
z=zs(zv);
totpix=x*y*z;

lowmass= str2num(get(handles.MassStart, 'String'));
highmass= str2num(get(handles.MassEnd, 'String'));
mbs= get(handles.MassBin, 'String');
mbv= get(handles.MassBin, 'Value');
massbin=str2num(mbs{mbv});
channels=(highmass-lowmass)/massbin;


[user sys]=memory;
datasize=totpix*channels*2;
SizeProblem=0;
if datasize > sys.PhysicalMemory.Available
    SizeProblem=1;
end;
datasize1=datasize/(1024*1024);  %calculate size in MB
if datasize1 > 1024 
    datasize1=datasize1/1024;
    set(handles.SpecdataSize, 'String',[num2str(datasize1,'%6.2f') ' GB']);
else
    set(handles.SpecdataSize, 'String',[num2str(datasize1,'%6.2f') ' MB']);
end
if SizeProblem==1
    set(handles.SpecdataSize, 'ForegroundColor',[1 0 0]);
else
    set(handles.SpecdataSize, 'ForegroundColor',[0 0 0]);
end

function BinnedSpec(handles)

lowmass= str2num(get(handles.MassStart, 'String'));
highmass= str2num(get(handles.MassEnd, 'String'));
if lowmass>=highmass
    %error here
end
mbs= get(handles.MassBin, 'String');
mbv= get(handles.MassBin, 'Value');
massbin=str2num(mbs{mbv});
channels=(highmass-lowmass)/massbin;
set(handles.SpecChannels, 'String',num2str(channels));
CalcSize (handles);

function DispImage(handles)
%displays the proper image on screen

global binnedimage meanimage binview;

if binview==0
    set(gcf,'CurrentAxes',handles.axes1);
    imagesc(meanimage);, axis image off; colormap(gray);
else
    if binview==1
        set(gcf,'CurrentAxes',handles.axes1);
        imagesc(binnedimage);, axis image off; colormap(gray);
    end
end


function StartDepth_Callback(hObject, eventdata, handles)
% hObject    handle to StartDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of StartDepth as text
%        str2double(get(hObject,'String')) returns contents of StartDepth as a double


% --- Executes during object creation, after setting all properties.
function StartDepth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to StartDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EndDepth_Callback(hObject, eventdata, handles)
% hObject    handle to EndDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EndDepth as text
%        str2double(get(hObject,'String')) returns contents of EndDepth as a double



% --- Executes during object creation, after setting all properties.
function EndDepth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EndDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes during object creation, after setting all properties.
function RawDepth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RawDepth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function RawHeight_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RawHeight (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function RawWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RawWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when selected object is changed in ImageSelect.
function ImageSelect_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in ImageSelect 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
global binview;

h=eventdata.NewValue;
q=get(h,'String');
if q(1:3)=='Raw'
   binview=0;
   DispImage(handles);
else
   binview=1;
   CalcBinned(handles);
end


% --- Executes on button press in EditCal.
function EditCal_Callback(hObject, eventdata, handles)
% hObject    handle to EditCal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.MassK0, 'Style', 'edit');
set(handles.MassSF, 'Style','edit');


% --------------------------------------------------------------------
function CloseFig_Callback(hObject, eventdata, handles)
% hObject    handle to CloseFig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close;


% --- Executes on selection change in ArrayType.
function ArrayType_Callback(hObject, eventdata, handles)
% hObject    handle to ArrayType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ArrayType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ArrayType


% --- Executes during object creation, after setting all properties.
function ArrayType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ArrayType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
